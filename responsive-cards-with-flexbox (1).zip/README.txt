A Pen created at CodePen.io. You can find this one at http://codepen.io/Katiae/pen/zwjmbW.

 Practicing responsive layouts using Flexbox, some css transitions and effects, and CoffeeScript.